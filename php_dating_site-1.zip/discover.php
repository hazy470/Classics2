<?php session_start(); if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Discover - Classic Dating</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header><h1>Classic Dating</h1>
<nav>
<a href="home.php">Home</a>
<a href="likes.php">Likes</a>
<a href="discover.php">Discover</a>
<a href="profile.php">Profile</a>
<a href="includes/logout.php">Logout</a>
</nav></header>
<main><h2>Discover Profiles</h2>
<div class="gallery">
<img src="images/user1.jpg" alt="User 1">
<img src="images/user2.jpg" alt="User 2">
</div></main></body></html>