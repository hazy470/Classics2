<?php session_start(); if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Likes - Classic Dating</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header><h1>Classic Dating</h1>
<nav>
<a href="home.php">Home</a>
<a href="likes.php">Likes</a>
<a href="discover.php">Discover</a>
<a href="profile.php">Profile</a>
<a href="includes/logout.php">Logout</a>
</nav></header>
<main><h2>Likes</h2><p>No new likes yet.</p></main>
</body></html>