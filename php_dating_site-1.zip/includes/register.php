<?php
$users = json_decode(file_get_contents("users.json"), true);
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

if (!isset($users[$username])) {
    $users[$username] = $password;
    file_put_contents("users.json", json_encode($users));
    echo "Registration successful. <a href='../index.php'>Login here</a>";
} else {
    echo "Username already exists. <a href='../register.php'>Try again</a>";
}
?>