<?php session_start(); if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - Classic Dating</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header><h1>Classic Dating</h1>
<nav>
<a href="home.php">Home</a>
<a href="likes.php">Likes</a>
<a href="discover.php">Discover</a>
<a href="profile.php">Profile</a>
<a href="includes/logout.php">Logout</a>
</nav></header>
<main><h2>Your Profile</h2>
<img src="images/user_profile.jpg" class="profile-pic" alt="Your Photo">
<p>Name: <?php echo $_SESSION['username']; ?></p>
<p>Age: 28</p>
<p>Location: City, Country</p>
</main></body></html>